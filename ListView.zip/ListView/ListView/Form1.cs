using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace FolderViewer
{
    public partial class Form1 : Form
    {
        private ImageList imageListLarge = new ImageList();
        private Dictionary<string, int> extensionIconIndex = new Dictionary<string, int>();

        public Form1()
        {
            InitializeComponent();

            imageListLarge.ImageSize = new Size(32, 32);
            imageListLarge.ColorDepth = ColorDepth.Depth32Bit;

            listView1.LargeImageList = imageListLarge;
            listView1.SmallImageList = imageListLarge;
            listView1.View = View.LargeIcon;

            buttonOpen.Click += buttonOpen_Click;
            listView1.DoubleClick += listView1_DoubleClick;
        }

        private void buttonOpen_Click(object? sender, EventArgs e)
        {
            string path = textBoxPath.Text.Trim();

            if (!Directory.Exists(path))
            {
                MessageBox.Show("���� ����� �� ����!", "�������",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ShowFolderContent(path);
        }

        private void ShowFolderContent(string path)
        {
            listView1.Items.Clear();
            imageListLarge.Images.Clear();
            extensionIconIndex.Clear();

            // ������ �����
            Icon folderIcon = GetSmallIcon(path, true);
            imageListLarge.Images.Add(folderIcon); // index 0

            // �����
            foreach (string dir in Directory.GetDirectories(path))
            {
                ListViewItem item = new ListViewItem(Path.GetFileName(dir));
                item.ImageIndex = 0;
                item.Tag = dir;
                listView1.Items.Add(item);
            }

            // �����
            foreach (string file in Directory.GetFiles(path))
            {
                string ext = Path.GetExtension(file).ToLower();

                int imageIndex;
                if (!extensionIconIndex.ContainsKey(ext))
                {
                    Icon fileIcon = GetSmallIcon(file, false);
                    imageListLarge.Images.Add(fileIcon);
                    imageIndex = imageListLarge.Images.Count - 1;
                    extensionIconIndex.Add(ext, imageIndex);
                }
                else
                {
                    imageIndex = extensionIconIndex[ext];
                }

                ListViewItem item = new ListViewItem(Path.GetFileName(file));
                item.ImageIndex = imageIndex;
                item.Tag = file;
                listView1.Items.Add(item);
            }
        }

        private void listView1_DoubleClick(object? sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0) return;

            string path = listView1.SelectedItems[0].Tag.ToString();

            if (Directory.Exists(path))
            {
                textBoxPath.Text = path;
                ShowFolderContent(path);
            }
            else if (File.Exists(path))
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(path)
                {
                    UseShellExecute = true
                });
            }
        }

        private Icon GetSmallIcon(string path, bool isFolder)
        {
            SHFILEINFO shinfo = new SHFILEINFO();
            uint attributes = isFolder ? FILE_ATTRIBUTE_DIRECTORY : FILE_ATTRIBUTE_NORMAL;
            uint flags = SHGFI_ICON | SHGFI_SMALLICON | SHGFI_USEFILEATTRIBUTES;

            SHGetFileInfo(path, attributes, ref shinfo, (uint)Marshal.SizeOf(shinfo), flags);

            Icon icon = (Icon)Icon.FromHandle(shinfo.hIcon).Clone();
            DestroyIcon(shinfo.hIcon);

            return icon;
        }

        [DllImport("Shell32.dll")]
        private static extern IntPtr SHGetFileInfo(
            string pszPath,
            uint dwFileAttributes,
            ref SHFILEINFO psfi,
            uint cbFileInfo,
            uint uFlags);

        [DllImport("User32.dll")]
        private static extern bool DestroyIcon(IntPtr hIcon);

        private const uint SHGFI_ICON = 0x100;
        private const uint SHGFI_SMALLICON = 0x1;
        private const uint SHGFI_USEFILEATTRIBUTES = 0x10;
        private const uint FILE_ATTRIBUTE_DIRECTORY = 0x10;
        private const uint FILE_ATTRIBUTE_NORMAL = 0x80;

        [StructLayout(LayoutKind.Sequential)]
        private struct SHFILEINFO
        {
            public IntPtr hIcon;
            public int iIcon;
            public uint dwAttributes;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string szDisplayName;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
            public string szTypeName;
        }
    }
}